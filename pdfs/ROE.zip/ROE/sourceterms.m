function [S]=sourceterms(r,u,ut,alpha,OMEGA,A,dA,E,p,x,nx,dx,k)

%define some parameres

Vol=A.*dx;              %volume of the cells
ut=u.*tan(pi/180*alpha);
Rm=1;                   %radius of the turbine at the midline
c=0.1;

%source terms due to geometry

    Sg(1,1:nx) = -r.*u./A.*dA ;
    Sg(2,1:nx) = -r.*u.^2./A.*dA ;
    Sg(3,1:nx) = -r.*u.*ut.*dA./A ;
    Sg(4,1:nx) = -r.*u./A.*dA.*(E+p./r) ;
    
%other source terms
    
    S1(1,1:nx) = 0 ;
    S1(2,1:nx) = 0 ; 
    S1(3,1:nx) = 0 ;
    S1(4,1:nx) = 0 ; 

%mass suorce terms

    %Sq(1,1:nx) = 0*(x>=0 & x<3 | x>3.1 & x<5.5 | x>5.6 & x<5.9 | x>6.1 & x<8.9  | x>9 & x<=10) + 100*(x>=3& x<=3.1 | x>=5.5 & x<=5.6 | x>=6 & x<=6.1 | x>=8.9 & x<=9 )  ;
    Sq(1,1:nx) = 0 ;%0*(x>=0 & x<4 | x>5.5 & x<5.8 |x>7 & x<=10) + 1e1*exp(-((x-4.75)/0.2).^2).*(x>=4 | x<=5.5) + 1e1*exp(-((x-6.55)/0.2).^2).*( x>=6 & x<=7 );
    Sq(2,1:nx) = -0 ;
    Sq(3,1:nx) = 0  ;
    %Sq(4,1:nx) = 0*(x>=0 & x<3 | x>3.1 & x<5.5 | x>5.6 & x<5.9 | x>6.1 & x<8.9  | x>9 & x<=10) + 100*1e2*(x>=3& x<=3.1 | x>=5.5 & x<=5.6 | x>=6 & x<=6.1 | x>=8.9 & x<=9 )  ;
    Sq(4,1:nx) = 0; %0*(x>=0 & x<4 | x>5.5 & x<5.8 |x>7 & x<=10) + 100*1e1*exp(-((x-4.75)/0.2).^2).*(x>=4 | x<=5.5) + 100*1e1*exp(-((x-6.55)/0.2).^2).*( x>=6 & x<=7 );
   
%momentum/energy source terms

    Sm(1,1:nx) = 0  ;  %momentum always zero
    Sm(2,1:nx) = -[r(1:nx-1).*A(1:nx-1).*u(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0].*tan(pi/180*alpha)./Vol ;
    Sm(3,1:nx) = [r(1:nx-1).*A(1:nx-1).*u(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0]./Vol ;

    if (k <= 200)
    
        Sm(4,1:nx) =  - 1/10*abs(([r(1:nx-1).*A(1:nx-1).*u(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0]./Vol).*OMEGA) ;                             %- 50*abs(([r(1:nx-1).*A(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0]./Vol).*OMEGA);       %-10*OMEGA;
    
    elseif (k > 200 || k < 1000)
    
        Sm(4,1:nx) =  - 1/6.*abs(([r(1:nx-1).*A(1:nx-1).*u(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0]./Vol).*OMEGA) ; 
    
    else
        
        Sm(4,1:nx) =  - abs(([r(1:nx-1).*A(1:nx-1).*u(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm,0]./Vol).*OMEGA) ;

    end
    
    %loss source (sink) terms

    Ss(1,1:nx) = 0  ;
    Ss(2,1:nx) = -0.5*c*r.*(u.^2+ut.^2) ;
    Ss(3,1:nx) = 0  ;
    Ss(4,1:nx) = -0.5*c*r.*(u.^2+ut.^2).^(1.5) ;
      
%sum of all source terms
    
    S=Sg+S1+Sq+Sm+Ss;

end
