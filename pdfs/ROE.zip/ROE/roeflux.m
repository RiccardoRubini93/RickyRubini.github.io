function [Flux,lambda]=roeflux(r,u,ut,p,U,H,gamma,L,R,nx)

 % Compute Roe Averages
    % Velovity 'u'
    u_avg = (sqrt (r(L)).*u(L) + sqrt (r(R)).*u(R))./ (sqrt(r(L))+sqrt(r(R)));
    %Velocity 'ut'
    ut_avg=(sqrt (r(L)).*ut(L) + sqrt (r(R)).*ut(R))./ (sqrt(r(L))+sqrt(r(R)));
    % Total Entalpy 'H'
    H_avg = (sqrt (r(L)).*H(L) + sqrt (r(R)).*H(R))./ (sqrt(r(L))+sqrt(r(R)));
    % Sound Speed 'a'
    a_avg = sqrt((gamma-1)*(H_avg-0.5*(u_avg.^2+ut_avg.^2)));

    % Compute Delta U's
    % dU = U(R)-U(L) at the cell boundaries { x_{i},x_{i+1}, ... }
    dU = U(:,R)-U(:,L);
    
    % Compute Fluxes at the cell centers
    % F = [F1 F2 F3]
   
    F = [r.*u; (r.*u.^2 + p); r.*u.*ut; (r.*u.*H)]; 
    
    % Fluxes to the left and right of 'F_ {i+1/2}'
    FL = F(:,L); 
    FR = F(:,R);
    
    % Scaled Right Eigenvectors are given by:
    k1 = [1*ones(1,nx-1); u_avg-a_avg; ut_avg; H_avg-u_avg.*a_avg];
    k2 = [1*ones(1,nx-1); u_avg      ; ut_avg; 1/2*(u_avg.^2+ut_avg.^2)];
    k3 = [1*ones(1,nx-1); u_avg+a_avg; ut_avg; H_avg+u_avg.*a_avg];
    k4 = [1*zeros(1,nx-1); 1*zeros(1,nx-1); 1*ones(1,nx-1); ut_avg]; %theta component
    
    % compute Roe waves strength alpha
    alpha2 = (gamma-1)./(a_avg.^2).*(dU (1,:).*(H_avg-u_avg.^2)+ u_avg.*dU(2,:) - dU(4,:));
    alpha1 = 1./(2*a_avg).*(dU (1,:).*(u_avg+a_avg)- dU(2,:)-a_avg.*alpha2);
    alpha3 = dU(1,:)-(alpha1 + alpha2);
    alpha4 = sqrt(r(L).*r(R)).*dU(3,:)./r(1:nx-1);
    
    % Eigenvalues of A at interface are (same as the original A mat)
    lambda(1,:) = abs(u_avg - a_avg);
    lambda(2,:) = abs(u_avg);
    lambda(3,:) = abs(u_avg + a_avg);
    lambda(4,:) = abs(u_avg);
    
    % Conditioning data
    alpha1 = repmat(alpha1,4,1);
    alpha2 = repmat(alpha2,4,1);
    alpha3 = repmat(alpha3,4,1);
    alpha4 = repmat(alpha4,4,1);
    
    lambda1 = repmat(lambda(1,:),4,1);
    lambda2 = repmat(lambda(2,:),4,1);
    lambda3 = repmat(lambda(3,:),4,1);
    lambda4 = repmat(lambda(4,:),4,1);
    
    % Roe Fluxes
    
    Flux = 0.5*(FL + FR) - 0.5*(alpha1.*lambda1.*k1 + alpha2.*lambda2.*k2 + alpha3.*lambda3.*k3 + alpha4.*lambda4.*k4);
    
    end
    
    
    