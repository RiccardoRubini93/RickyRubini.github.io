function [A,dA,fun]=duct_shape(nx,x,type,a)

if type==0

    A(1:nx)=1;
    dA(1:nx)=0;
    fun(1,nx)=1;
    fun(2,nx)=0;

end

if type==1

A=1-2*a/sqrt(2*pi).*exp(-2*(x-5).^2);
fun(1,:)=0.5-1*a/sqrt(2*pi).*exp(-2*(x-5).^2);
fun(2,:)=1*a/sqrt(2*pi).*exp(-2*(x-5).^2)-0.5;
dA=2*a*2.*exp(-2*(x-5).^2)*sqrt(2/pi).*(x-5);    

end

%de laval nozzle with throath section in x=10
% convergent duct

if type==2

  A=(1-0.661514*exp(-log(2)*((x-10)/6).^2)).*(x>=0 & x<=10) +  0.3385*(x>10 & x<15);                                   %+(0.536572-0.198086*exp(-log(2).*((x-10)/6).^2)).*(x>10 & x<20);
  
  dA=num_derive(x,nx,A);
  fun=0;

end


end

