%quasi 1D trougthflow model using finite volume method with approximate riemann solver: Roe scheme and Rusanov scheme 
clc;
close all;
clear all;

%geometrical parametres

nx=50;
nt=5000;
mx=nx+1;
L=10;
PH=5e5;
P=1e5;
t=0;
CFL=0.5;      %keep low value if there is ashock
gamma=1.4;
a=0;        %better if less than 0.5
Rm=1;

% Domain

xn = linspace(0,L,mx);          % cells nodes
dx = max(xn(2:mx)-xn(1:mx-1));  % Cell size
x  = xn(1:mx-1)+dx/2;        	% Cell centers

alpha=0*(x>=0 & x<03) + 20*(x-3).*(x>3 & x<5.5) + 20*2.5*(x>= 5.5 & x<=6) +20*(11.5 - 1.5*x).*(x>6 & x<9) - 40 *(x>=9 & x <=10); %define flow angle as afunction of x
OMEGA = 0*(x>=0 & x<6 | x>9 & x<=10) + 1000*(x>=6 & x<=9) ; %define angoular speed

% 0 condizioni a contorno per tubo a shock 1 conv div

type=1;

%condizioni al contorno flusso quasi 1D
[A,dA,fun]=duct_shape(nx,x,type,a);

%initial conditions tubo a shock %add initial conditions for theta
%component of velocity

    r(1:nx)=1.5;
    u(1:nx)=50;
    ut(1:nx)=0; %u.*tan(pi/180.*alpha); %tan(falpha).*u;
    p(1:2)=1.5*P;
    p(1:nx)=P; 
          
    e_s = p./((gamma-1).*r);
    e = p./(gamma-1);
    E = e + 1/2*r.*(u.^2+ut.^2);
    H = gamma/(gamma-1)*p./r + (u.^2+ut.^2)/2;
 
  % Build vectors
  
    L = 1:nx-1;       %inner nodes
    R = 2:nx;         % middle points
    % U = [U1 U2 U3]' % defined at every cell center
    
    U = [r; r.*u; r.*ut; E];
        
    % U1 = Density, U2 = Momentum, U3 = Total Energy
 
    U_next=zeros(4,nx);
    UL_next=zeros(4,nx);
    k=0;
    tic 
  
  for n=1:1:nt
    
	k=k+1;
    a=U(1,:);
    
    %condizioni al contorno
    
    p(1)=1.5*P;
    p(nx)=P;
    u(1:nx)=50;
    r(1)=1.5;    
    ut(1) = 0;    


    e_s = p./((gamma-1).*r);
    e = p./(gamma-1);
    E = e + 1/2*r.*(u.^2+ut.^2);
    H = gamma/(gamma-1)*p./r + (u.^2+ut.^2)/2;
   
    U = [r; r.*u; r.*ut; E];
    
    %Roe flux calculation
    
    [Flux,lambda] = roeflux(r,u,ut,p,U,H,gamma,L,R,nx);
    
    [S] = sourceterms(r,u,ut,alpha,OMEGA,A,dA,E,p,x,nx,dx,k);
    
    %time step using CFL conditions

    dt= CFL*dx/max([lambda(1,:) lambda(2,:) lambda(3,:) lambda(4,:)]);
    
    for i=2:1:nx-1 
        
        U_next(:,i)=U(:,i)-dt/dx*(Flux(:,i)-Flux(:,i-1))+dt*S(:,i);
    
    end
    
    %Neumann boundary conditions
    U_next(:,1)=U_next(:,2);
    U_next(:,nx)=U_next(:,nx-1);
    
    
    % Compute variables of the new time step
    r_next = U_next(1,:);                                               % Density
    u_next = U_next(2,:)./U_next(1,:);                                  % axial Velocity
    ut_next= U_next(3,:)./U_next(1,:);                                  % theta velocity
    E_next = U_next(4,:);                                               % Total Energy
    p_next = (gamma-1).*(E_next-r_next.*(u_next.^2+ut_next.^2)/2);      % Pressure
    e_next = 1/(gamma-1)*(p_next./r_next);                              % Internal Energy
    a_bar_next = sqrt(gamma*p_next./r_next);                            % sound speed
    m_next = u_next./a_bar_next;                                        % Mach 
    s_next = log(p_next./r_next.^gamma);                                % Entropy
    H_next = (E_next + p_next)./r_next;                                 % Enthalpy

    % Update info
    U = U_next;
    r = r_next;
    u = u_next;
    ut= ut_next;
    e = e_next;
    p = p_next;
    m = m_next;
    s = s_next;
    H = H_next;


    p(1)=1.5*P;
    p(nx)=P;
    r(1)=1.5; 
    u(1:nx)=50;   
    ut(1) = 0;
    
	Ft = [r(1:nx-1).*A(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm/dx] ;
  	Fx = ([Ft,0].*(tan(pi/180*alpha))) ;
  	Pt = abs([Ft,0].*OMEGA) ;
    
    
    %plot of residuals
    
    a=a(1:nx-2);
    b=U(1,1:nx-2);
    res_rho(n)=abs(mean(a-b));
    xx(n)=n;
    n
    t=t+dt
    	figure(1)
    	semilogy(xx,res_rho);
	
	figure(2)
  	subplot(2,3,1)
  	plot(x,p)
	title('Pressure')
  	subplot(2,3,2)
  	plot(x,ut)
	title('Tang Vel')
  	subplot(2,3,3)
  	plot(x,u)
	title('Axial vel')
  	subplot(2,3,4)
  	plot(x,m)
	title('Mach')  
  	subplot(2,3,5)
  	plot(x,sqrt(u.^2+ut.^2))
	title('AbsU')
  	subplot(2,3,6)
  	plot(x(1:nx-1),Ft)
	title('Tang Force')    
	pause(0.01);
    	hold on

    
  end
  
  Time=toc
  pause()

  %check angular momentum conservation
  
  %define angouar momentum
  
  Ft = [r(1:nx-1).*A(1:nx-1).*(ut(2:nx)-ut(1:nx-1))*Rm/dx] ;
  Fx = ([Ft,0].*(tan(pi/180*alpha))) ;
  Pt = abs([Ft,0].*OMEGA) ;
  
  
                        
    
    
     
     
  



