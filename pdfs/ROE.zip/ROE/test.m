%test script for duct shape and source terms

x=[0:0.01:10];

%step model for angoular velocity (50 rad/sec) rotor blade from x=6 to x=9
%stator blade from x=3 to x=5.5 

Omega1 = 0*(x>=0 & x<6 | x>9 & x<=10) + 50*(x>=6 & x<=9) ;

%injection at the beginning and end of stator and rotor blade

%mass source term

Q_in = 0*(x>=0 & x<3 | x>3.1 & x<5.5 | x>5.6 & x<5.9 | x>6.1 & x<8.9  | x>9 & x<=10) + 1e2*(x>=3& x<=3.1 | x>=5.5 & x<=5.6 | x>=6 & x<=6.1 | x>=8.9 & x<=9 );
Q_inj= 0*(x>=0 & x<5.5 | x>5.6 & x<5.9 |x>6.1 & x<=10) + 1e2*exp(-(x-5.5).^2/(0.001)).*(x>=5.4 | x<=5.6) + 1e2*exp(-(x-6).^2/(0.001)).*( x>=5.9 & x<=6.1 );


%x momentum soure term

%Px=Q_in.*u_in;

%tetha momentum source term

%Ptetha=Q_in.*u_tin;

%energy source term

%E_in=Q_in.*h_in;

%turbine duct shape alpha as a function of x

%tan(beta)=ut./ux;

%define beta

%beta=0*(x>=0 & x<3);

alpha=0*(x>=0 & x<03) + (x-3).*(x>3 & x<5.5) + 2.5*(x>= 5.5 & x<=6) +(11.5 - 1.5*x).*(x>6 & x<9) - 2 *(x>=9 & x <=10);

plot(x,Q_inj)