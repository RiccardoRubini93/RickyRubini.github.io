% finite volume code to solve a the shock tube problem
clc;
close all;
clear all;

%geometrical  and phisical parameters 


nx=500;
mx=nx+1;
L=50;
gamma=1.4;

%time stepping parameters

nt=2000;
t0=0;
CFL=0.95;

a=0.5;  

% Domain
xn = linspace(0,L,mx);          % cells nodes
dx = max(xn(2:mx)-xn(1:mx-1));  % Cell size
x  = xn(1:mx-1)+dx/2;        	% Cell centers

%Initial conditions for shock tube
    
    p_l=1;
    p_r=0.1;
    rho_l=1;
    rho_r=0.125;
    u_l=0;
    u_r=0;

    p(1:(nx)/2)=p_l;
    p((nx)/2:nx)=p_r;
    r(1:(nx)/2)=rho_l;
    r((nx)/2:nx)=rho_r;
    u(1:(nx)/2)=u_l;
    u((nx)/2:nx)=u_r;
       
    
e_s = p./((gamma-1).*r);
e = p./(gamma-1);
E = e + 1/2*r.*u.^2;
H = gamma/(gamma-1)*p./r + u.^2/2;

%Flux limiter to avoid overshooting

    for i = 2:nx-1
        if (x(i) < 0.335)
            h(i)=1;
        elseif x(i) > 0.675
            h(i)=0;
        else
            h(i)= (x(i)-0.675)/(0.335-0.675);
        end
    end
 
% Build vector U and dU, and F

L = 1:nx-1;     %inner nodes
R = 2:nx;        % middle points


%vector of conserved variables defined in every cell center    
U = [r; r.*u; E];

%Initialization       
 
U_next=zeros(3,nx);
UL_next=zeros(3,nx);
     
%pseudo time loop
  
for n=1:1:nt

    e = p./(gamma-1);
    E = e + 1/2*r.*u.^2;
    H = gamma/(gamma-1)*p./r + u.^2/2;

    U = [r; r.*u; E];
    
    a=U(2,:);
     
    [Flux,lambda_bar]=roeflux(r,u,p,U,H,gamma,L,R,nx);
    
    %time step using CFL conditions

    dt= CFL*dx/max([lambda_bar(1,:) lambda_bar(2,:) lambda_bar(3,:)]);
    
    for i=2:1:nx-1
        
        U_next(:,i)=U(:,i)-dt/dx*(1-h(i))*(Flux(:,i)-Flux(:,i-1));
    
    end
    
    
    %boundary condition
    
    U_next(:,1)=U_next(:,2);
    U_next(:,nx)=U_next(:,nx-1);
   
    
    % Compute variables of the new time step
    r_next = U_next(1,:);                               % Density
    u_next = U_next (2,:)./U_next(1,:);                 % Velocity
    E_next = U_next(3,:);                               % Total Energy
    p_next = (gamma-1).*(E_next-r_next.*u_next.^2/2);   % Pressure
    e_next = 1/(gamma-1)*(p_next./r_next);              % Internal Energy
    a_bar_next = sqrt(gamma*p_next./r_next);            % sound speed
    m_next = u_next./a_bar_next;                        % Mach 
    s_next = log(p_next./r_next.^gamma);                % Entropy
    H_next = (E_next + p_next)./r_next;                 % Enthalpy
    
   
    % Update info
    U = U_next;
    r = r_next;
    u = u_next;
    e = e_next;
    p = p_next;
    m = m_next;
    s = s_next;
    H = H_next;
  
    %plot residual and some physical quantities  
    
    b=U(2,:);
    res_rho(n)=mean(abs(a-b));
    xx(n)=n;
    n
  
    figure(1)
    semilogy(xx,res_rho);
    
    
    figure(2)
    
    subplot(1,3,1)
    plot(x,p,'o--')
    xlabel('x') 
    ylabel('pressure')
    
    subplot(1,3,2)
    plot(x,m,'o--')
    xlabel('x') 
    ylabel('Mach')

    subplot(1,3,3)
    plot(x,s,'o--')
    xlabel('x') 
    ylabel('Entropy')

   
    pause(0.01)
    
    
  end
  
  T_fin=n*dt
  
  
  pause()
  

  
  
                        
    
    
     
     
  



