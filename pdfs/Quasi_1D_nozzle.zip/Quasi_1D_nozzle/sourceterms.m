function [S]=sourceterms(r,u,A,dA,E,p)

%computation of the source terms due to the quasi 1_D shape of the nozzle

    S(1,:) = -r.*u./A.*dA ;
    S(2,:) = -r.*u.^2./A.*dA;
    S(3,:) = -r.*u./A.*dA.*(E+p./r);

end