function [dA]=num_derive(x,nx,A)

%function to compute the numerical derivative of the shape of the duct in case is not defined by an analytical solution

for k=1:1:nx-1
    
    dA(k)=(A(k+1)-A(k))/(x(k+1)-x(k));
end

dA(nx)=dA(nx-1);

end