function [A,dA,fun]=duct_shape(nx,x,a)

%Gaussain nozzle shape centred in x=5

A=1-2*a/sqrt(2*pi).*exp(-2*(x-5).^2);
fun(1,:)=0.5-1*a/sqrt(2*pi).*exp(-2*(x-5).^2);
fun(2,:)=1*a/sqrt(2*pi).*exp(-2*(x-5).^2)-0.5;
dA=2*a*2.*exp(-2*(x-5).^2)*sqrt(2/pi).*(x-5);    

end
